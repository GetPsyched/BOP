#include <stdio.h>

int main()
{
  char ch;
  printf("Enter a character --> ");
  scanf("%c", &ch);
  printf("\nThe ascii value of the ch variable is --> %d", ch);

}
